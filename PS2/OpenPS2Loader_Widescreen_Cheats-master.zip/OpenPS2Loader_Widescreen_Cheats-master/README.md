# OpenPS2Loader_Widescreen_Cheats
Drop these cheat files in your /OPL/CHT folder to correct/add widescreen support for your PS2 games!

So you have some sexy component cables on your big widescreen TV and you think you are ballin' hard?
Well sorry to break it to you but you aren't.
Most games do not have widescreen support so they just stretch the image.
Some games have widescreen options but they aren't always a proper widescreen.

These cheats will give you the best experience!

These work with OpenPS2Loader 0.9.3 (The latest stable build) and I have tested it on the current (as of 6/6/19) dev build 1564_DB-TA_all which also worked fine.

I am testing these on a FAT (v9) PS2 using FMCB.

Just make sure you go to "Cheat Settings" and change "Enable PS2RD Cheat Engine" to "On" and change "PS2RD Cheat Engine Mode" to "Auto-select cheats".

This doesn't have every single game, and they haven't all been tested, but I am working on it. 

I am converting the .pnach files from this Widescreen patch archive:
https://forums.pcsx2.net/Thread-PCSX2-Widescreen-Game-Patches

Props to the original creators of these cheats! (Which are made for emulator use).

Example:
<img src="https://i.imgur.com/gYElt.giff">

Here is a short list of games added: https://www.dropbox.com/s/5j2zxu68003jubw/Games.xlsx?dl=1

I update it as I go and i'll make it more final once all of them are tested and verified.
